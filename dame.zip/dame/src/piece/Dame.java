package piece;

public class Dame extends Piece {

	public Dame(int id,char motif, int i, int j) {
		super(id,motif,i,j);
	}

}
