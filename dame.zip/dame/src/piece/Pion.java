package piece;

public class Pion extends Piece {

	public Pion(int id,char motif, int i, int j) {
		super(id,motif,i,j);
	}

}
